/*
    USBKeyInject Firmware v1.02 for attiny85 processor for implementing a key injector over USB as a HID device
    Copyright (C) 2010  NOP Security

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

//You must set attiny85 fuses to:
//#define	HIGHFUSE	0xDF
//#define	LOWFUSE		0xC1
//PLL clock + No clkdiv

#define	TRUE		1
#define	FALSE		0

#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "usbdrv/usbdrv.h"
#include "./usbconfig.h"
#include "./USBKeyInject.h"
#include "./libs-device/osccal.c"
#include "./ExtSerialEEPROM.c"

PROGMEM char usbHidReportDescriptor[USB_CFG_HID_REPORT_DESCRIPTOR_LENGTH] = {
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
    0x09, 0x06,                    // USAGE (Keyboard)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x85, 0x01,                    //   REPORT_ID (1)
    0x05, 0x07,                    //   USAGE_PAGE (Keyboard)
    0x19, 0xe0,                    //   USAGE_MINIMUM (Keyboard LeftControl)
    0x29, 0xe7,                    //   USAGE_MAXIMUM (Keyboard Right GUI)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x01,                    //   LOGICAL_MAXIMUM (1)
    0x75, 0x01,                    //   REPORT_SIZE (1)
    0x95, 0x08,                    //   REPORT_COUNT (8)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0x25, 0xDF,                    //   LOGICAL_MAXIMUM (223)
    0x19, 0x00,                    //   USAGE_MINIMUM (Reserved (no event indicated))
    0x29, 0xDF,                    //   USAGE_MAXIMUM (Reserved)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x95, 0x01,                    //   REPORT_COUNT (1)
    0x81, 0x00,                    //   INPUT (Data,Ary,Abs)
    0xc0,                          // END_COLLECTION
    0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
    0x09, 0x00,                    // USAGE (Undefined)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x09, 0x00,                    //   USAGE (Undefined)
    0x85, 0x02,                    //   REPORT_ID (2)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x26, 0xff, 0x00,              //   LOGICAL_MAXIMUM (255)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x95, 0x04,                    //   REPORT_COUNT (4)
    0x91, 0x02,                    //   OUTPUT (Data,Var,Abs)
    0x09, 0x00,                    //   USAGE (Undefined)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x26, 0xff, 0x00,              //   LOGICAL_MAXIMUM (255)
    0x95, 0x02,                    //   REPORT_COUNT (2)
    0x75, 0x08,                    //   REPORT_SIZE (8)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0xc0                           // END_COLLECTION
};

unsigned char HexMap[]={
0x27,		//Ascii 0x30 '0'
0x1E,		//Ascii 0x31 '1'
0x1F,		//Ascii 0x32 '2'
0x20,		//Ascii 0x33 '3'
0x21,		//Ascii 0x34 '4'
0x22,		//Ascii 0x35 '5'
0x23,		//Ascii 0x36 '6'
0x24,		//Ascii 0x37 '7'
0x25,		//Ascii 0x38 '8'
0x26,		//Ascii 0x39 '9'
0x04,		//Ascii 0x61 'a'
0x05,		//Ascii 0x62 'b'
0x06,		//Ascii 0x63 'c'
0x07,		//Ascii 0x64 'd'
0x08,		//Ascii 0x65 'e'
0x09,		//Ascii 0x66 'f'
};

#define	ECHBUFSIZE	82
#define	ACTBUFSIZE	128

unsigned char	scancode[3];	//scancode storage
unsigned char	modKeys;		//modifier key storage
unsigned char	outrbuf[3];		//USB output data buffer
unsigned char	statusRbyte;	//status return buffer
unsigned char	bufRbyte;		//return data buffer
unsigned int	cmdEEPtr;		//current EEPROM position in active page
unsigned int	cmdEETmp;

unsigned char	usbIdle;		//required USB idle rate data
unsigned char	blinkTime;		//blinking?
unsigned char	apsec4;			//quarter seconds counter
unsigned char	apmin;			//minutes counter
unsigned char	aphour;			//hours counter
unsigned char	timeWait;		//wait command type
unsigned char	timeWVal;		//wait length value

unsigned char	echcBuffer[ECHBUFSIZE];	//echo character code keys buffer
unsigned char	echmBuffer[ECHBUFSIZE];	//echo character modifier keys buffer
unsigned char	echBufEnd;				//buffer end point

int				exEEPage;		//External EEPROM buffer page
unsigned int	exEEOffSec;
unsigned char	shadowbuf[ACTBUFSIZE];	//Ext EEPROM shadow
unsigned char	exEERestart;
unsigned char	hextype;				//echo hex type
unsigned char	holdkey;				//hold echo keys - must manual clear holds

unsigned char	starting_up;	//equals 1 if still in startup idle


//oddly enough, this works best in this file - a few devices won't calibrate when this is located in other source files... *wonders*
void usbEventResetReady(void)
{
    calibrateOscillator();
}

void timerInit() //set up timer prescaler
{

	TCCR1	= 0x0F;  // Clock/16384 = 1007 hz, 977/256 = 3.933hz per overflow
	TIMSK  |= 1<<TOIE1;

}

char echPushFIFO(unsigned char code, unsigned char mod) // character echo FIFO push function
{
	if(echBufEnd >= ECHBUFSIZE) return(0);

	echcBuffer[echBufEnd]=code;
	echmBuffer[echBufEnd++]=mod;

	return(1);
}

void echPopFIFO() // character echo FIFO pop function
{unsigned char x;

	if(!echBufEnd) return;

	for(x=1; x<echBufEnd; x++){ //slow but small code size shift
		echcBuffer[x-1]=echcBuffer[x];
		echmBuffer[x-1]=echmBuffer[x];
		}
	echBufEnd--;

	return;
}

usbMsgLen_t usbFunctionSetup(uchar data[8]) //USB message processing
{usbRequest_t *setupReq = (void *)data;

    if((setupReq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS){
        if(setupReq->bRequest == USBRQ_HID_GET_REPORT){
			if(setupReq->wValue.bytes[0] == 2){ //get report ID 2
			    usbMsgPtr = outrbuf;
				outrbuf[0] = 2;
				outrbuf[1] = statusRbyte;
				outrbuf[2] = bufRbyte;
				if(statusRbyte == STATUSR_COMPLETE || 
				   statusRbyte == STATUSR_EOF ||
				   statusRbyte == STATUSR_RETRY) statusRbyte=STATUSR_IDLE;
				return(3);
				}
			else{ //just in case
			    usbMsgPtr = scancode;
				return sizeof(scancode);
				}
        	}
        if(setupReq->bRequest == USBRQ_HID_SET_REPORT){ //set report forwarded to usbFunctionWrite
			return(USB_NO_MSG);
        	}
		if(setupReq->bRequest == USBRQ_HID_SET_IDLE){
            usbIdle = setupReq->wValue.bytes[1];
    	    }
		if(setupReq->bRequest == USBRQ_HID_GET_IDLE){
            usbMsgPtr = &usbIdle;
            return(1);
        	}
    	}

	return(0);
}

uchar startEERead(uchar addrl, uchar addrh) //EEPROM check and read
{unsigned int addr = (addrh<<8) + addrl;
	if(statusRbyte != STATUSR_IDLE) return(0);
	statusRbyte = STATUSR_EEBUSY;
	if(exEEPage==-1) bufRbyte = eeprom_read_byte( (const void *) addr);
	else{
		if(exEEcur == EXEECMD_IDLE){
			exEEcur=EXEECMD_ADDRNRD;
			exEEAddr=addr;
			exEEstt=0;
			exEELen=1;
			bufRbyte=0;
			exEEPtr=&bufRbyte;
		}
		else statusRbyte = STATUSR_RETRY;
	}
	return(1);
}

uchar startEEWrite(uchar addrl, uchar addrh, uchar newbyte) //EEPROM check and write
{unsigned int addr = (addrh<<8) + addrl;
	if(statusRbyte != STATUSR_IDLE) return(0);
	statusRbyte = STATUSR_EEBUSY;
	if(exEEPage==-1) eeprom_update_byte( (void *) addr, newbyte);
	else{
		if(exEEcur == EXEECMD_IDLE){
			exEEcur=EXEECMD_WRITEBT;
			exEEAddr=addr;
			exEEstt=0;
			exEELen=1;
			tempwr =newbyte;
			exEEPtr=&tempwr;
		}
		else statusRbyte = STATUSR_RETRY;
	}
	return(1);
}

void updateEEBusy() //update USB EEPROM command status if waiting, and signal with COMPLETE or retry busy external mem
{
	if(statusRbyte != STATUSR_EEBUSY) return;
	if(exEEPage==-1 && eeprom_is_ready()) statusRbyte = STATUSR_COMPLETE;
	if(exEEPage==-1 && !serEExist) return;
	if(exEEcur == EXEECMD_DONE){
		statusRbyte = STATUSR_COMPLETE;
		exEEcur = EXEECMD_IDLE;
	}
	else if(exEEcur == EXEECMD_NOACK){
		exEEstt=0;
		exEEcur = exEElast;
	}
	return;
}

uchar usbFunctionWrite(uchar *data, uchar len) //process USB report 2 commands
{uchar command;
	command = data[1]; // data[1] = command, data[2]-data[4] = data

	if(command == CONTROL_CLEAR_STATUS){
		statusRbyte=STATUSR_IDLE;
		return(1);
		}
	if(statusRbyte == STATUSR_BUSY) return(-1);

	switch(command){
		case CONTROL_READ_EEBLOC: // Read EEPROM location
			if(exEEPage==-1 && (((unsigned int)data[3]<<8) + data[2]) > EECMDPTR_END){
				statusRbyte = STATUSR_EOF;
				return(1);
				}
			if(!startEERead(data[2], data[3])) return(-1);
			break;
		case CONTROL_WRITE_EEBLOC: // Write EEPROM location
			if(exEEPage==-1 && (((unsigned int)data[3]<<8) + data[2]) > EECMDPTR_END){
				statusRbyte = STATUSR_EOF;
				return(1);
				}
			if(!startEEWrite(data[2], data[3], data[4])) return(-1);
			break;
		case CONTROL_SETEECMDPTR: //Set script command pointer address
			cmdEEPtr = (((unsigned int)data[3]<<8) + data[2]);
			exEEOffSec=-1;
			statusRbyte = STATUSR_COMPLETE;
			break;
		case CONTROL_SET_EXEEPAGE: //Set external EEPROM page
			if(!serEExist){
				statusRbyte = STATUSR_EOF;
				return(1);
				}
			exEEOffSec=-1;
			exEEPage = (((unsigned int)data[3]<<8) + data[2]);
			statusRbyte = STATUSR_COMPLETE;
			break;
		case CONTROL_GET_EXEEPAGE: //Get external EEPROM page
			if(!serEExist || exEEPage==-1){
				statusRbyte = STATUSR_EOF;
				return(1);
				}
			bufRbyte = exEEPage;
			statusRbyte = STATUSR_COMPLETE;
			break;
		case CONTROL_QECHOCHAR: //Queue echo character into FIFO
			if(echPushFIFO(data[2], data[3])) statusRbyte = STATUSR_COMPLETE;
			else{
				statusRbyte = STATUSR_EOF;
				return(1);
				}
			break;
		case CONTROL_STHOLDCHAR: //Set hold key check value
			holdkey = data[2];
			statusRbyte = STATUSR_COMPLETE;
			break;
		case CONTROL_ENABLE: //Enable script processing on current page
			cmdEEPtr = 0;
			statusRbyte = STATUSR_COMPLETE;
			break;
		case CONTROL_DISABLE: //Disable script processing
			cmdEEPtr = -1;
			statusRbyte = STATUSR_COMPLETE;
			break;
		case CONTROL_BLINK: //Blink LED if attached
			blinkTime += data[2];
			break;
		default:
			break;
		}

	return(1);
}

ISR(TIM1_OVF_vect, ISR_NOBLOCK) // general timing delay using timer overflow interrupt
{
	if(starting_up && starting_up<STARTUPDELAY){ // startup delay before writing and to allow recovery
		starting_up++;
		return;
		}
	else starting_up=0;
	
	apsec4++; // timing in ~quarter seconds 
	if(apsec4>236){ apmin++; apsec4=0;} //~236 cycles per minute at ~3.933hz
	if(apmin>60){ aphour++; apmin=0;} //off by a few seconds per minute to hour depending on processor speed and processing
	return;
}

void clearTimer1() //zero out timer for script timing start
{
	TCNT1 =0;
	apsec4=0;
	apmin =0;
	aphour=0;
	return;
}

uchar checkTimer1() //check if we should delay due to timer wait, process once each main script loop
{
	if(timeWait == 0) return(1);
	if(timeWait == EECMD_DELAYQ && (apsec4 || apmin || aphour)){
		timeWait=0;
		return(1);
		}
	if(timeWait == EECMD_DELAYSEC && (apsec4 >= (timeWVal<<2) || apmin || aphour)){
		timeWait=0;
		return(1);
		}
	if(timeWait == EECMD_DELAYMIN && (apmin >= timeWVal || aphour)){
		timeWait=0;
		return(1);
		}
	if(timeWait == EECMD_DELAYHR && aphour >= timeWVal){
		timeWait=0;
		return(1);
		}
	return(0);
}

void blinkit(uchar blinks, uchar bldelay) //blink test LED if connected.
{unsigned char i, b=blinks<<1;

    for(;b>0;b--){
		PORTB ^= (1<<PORTB4);
	    for(i=0;i<bldelay;i++){
	        _delay_ms(15);
			}
    	}
	PORTB &= ~(1<<PORTB4);
	return;
}

void check_eeprombt()
{unsigned int eetarget;
	if(   !serEExist
		|| exEEPage==-1
		|| exEEcur != EXEECMD_IDLE 
		|| statusRbyte == STATUSR_EEBUSY 
		|| cmdEEPtr==-1 ) return;

	if(exEERestart){
		eetarget=cmdEEPtr;
		exEEOffSec=-1;
		exEERestart=0;
		}
	else if(cmdEEPtr){
		eetarget=(cmdEEPtr+0x40)&0xFFC0;
		}
	else{
		eetarget=cmdEEPtr;
		exEEOffSec=-1;
		}

	if(exEEOffSec == eetarget) return;
	
	statusRbyte = STATUSR_EEBUSY;
	exEEcur=EXEECMD_ADDRNRD;
	exEEAddr=eetarget;
	exEEstt=0;
	exEELen=0x40;
	exEEPtr=shadowbuf+(eetarget&0x40);
	exEEOffSec=eetarget;
	
	return;
}

unsigned char read_eeprombt()
{
	if(!serEExist || exEEPage==-1) return(eeprom_read_byte( (const void *) cmdEEPtr));
	return(shadowbuf[cmdEEPtr&0x7F]);
}

void cmdProcessPtr() //process stored scripting commands
{uchar curcmd; unsigned char tmpx, tmpy;

	if(cmdEEPtr == -1) return; // return: not processing
	if(!checkTimer1()) return; // return: timer wait
	if(!eeprom_is_ready()) return; // return: internal EEPROM is busy
	if(serEExist && exEEPage!=-1 && (exEEOffSec==-1 || exEEcur != EXEECMD_IDLE)) return; // return: wait for external eeprom to be valid

	if(exEEPage==-1 && (cmdEEPtr < EECMDPTR_INIT || cmdEEPtr > EECMDPTR_END)) cmdEEPtr = EECMDPTR_INIT; // check if command address is valid

	curcmd = read_eeprombt(); // get next int/ext EEPROM byte
	if(curcmd < EECMDSTART){
		USB_INTR_ENABLE |= (1 << USB_INTR_ENABLE_BIT);
		usbDeviceConnect();
		if(usbInterruptIsReady()){ //send next code if ready
			scancode[0] = 1;
			scancode[1] = modKeys;
			scancode[2] = curcmd;
			usbSetInterrupt(scancode, sizeof(scancode));
			cmdEEPtr++;
			}
		return;
		}
	switch(curcmd){
		case EECMD_PAGE: //Set new page and address <page><highbyte><lowbyte> (unsigned)
			exEEOffSec=-1;
			cmdEEPtr++;
			tmpx = read_eeprombt();
			cmdEEPtr++;
			cmdEETmp  = read_eeprombt()<<8;
			cmdEEPtr++;
			cmdEETmp |= read_eeprombt();
			cmdEEPtr  = cmdEETmp;
			if(tmpx==-1) exEEPage = -1;
			else exEEPage = tmpx;
			exEERestart = 1;
			break;
		case EECMD_STRHEX16: //Output string hex: + 16 bytes
		case EECMD_STRHEXS: //Output string hex: count + count bytes (max 16) or set hex mode
		case EECMD_STRHEX: //Output string hex: single byte
			if(curcmd==EECMD_STRHEXS){
				cmdEEPtr++;
				tmpy  = read_eeprombt();
				if(tmpy>HEXEN_BASE){ // Set hex type if count is out of range and over Hex Encoding Base ID
					hextype=tmpy;
					tmpy=0;
				}
				else if(tmpy > 16) tmpy=16;
			}
			else if(curcmd==EECMD_STRHEX16) tmpy=16;
			else tmpy=1;
			while(tmpy--){
				cmdEEPtr++;
				tmpx  = read_eeprombt();
				if(hextype==HEXEN_VAR){ // Variable encoding (0x00)
					echPushFIFO(0x27, 0); // '0'
					echPushFIFO(0x1B, 0); // 'x'
				}
				else if(hextype==HEXEN_RAW); // No prefix - raw hex (00)
				else{ // Defaults to string encoding if FF or unknown (\x00)
					echPushFIFO(0x31, 0); // '\'
					echPushFIFO(0x1B, 0); // 'x'
				}
				echPushFIFO(HexMap[(tmpx>>4)&0x0F], 0); // high 4 bits
				echPushFIFO(HexMap[(tmpx   )&0x0F], 0); // low 4 bits
				if(hextype==HEXEN_VAR) echPushFIFO(0x36, 0); // follow with comma also if variable-style hex
			}
			cmdEEPtr++;
			break;
		case EECMD_JUMP: //Jump to current location + <highbyte><lowbyte> (signed - by overflow)
			cmdEEPtr++;
			cmdEETmp  = read_eeprombt()<<8;
			cmdEEPtr++;
			cmdEETmp |= read_eeprombt();
			cmdEEPtr += cmdEETmp;
			exEERestart=1;
			break;
		case EECMD_GOTO: //Goto command buffer location <highbyte><lowbyte> (unsigned)
			cmdEEPtr++;
			cmdEETmp  = read_eeprombt()<<8;
			cmdEEPtr++;
			cmdEETmp |= read_eeprombt();
			cmdEEPtr  = cmdEETmp;
			exEERestart=1;
			break;
		case EECMD_STMODKEYS: //Set modifier keys
			cmdEEPtr++;
			modKeys = read_eeprombt();
			cmdEEPtr++;
			break;
		case EECMD_DELAYSEC: //delay times
		case EECMD_DELAYMIN:
		case EECMD_DELAYHR:
			cmdEEPtr++;
			timeWait = curcmd;
			timeWVal = read_eeprombt();
			clearTimer1();
			cmdEEPtr++;
			break;
		case EECMD_DELAYQ: //delay one overflow
			timeWait = curcmd;
			clearTimer1();
			cmdEEPtr++;
			break;
		case EECMD_NOP: //NOP (Delay of one script processing cycle)
			cmdEEPtr++;
			break;
		case EECMD_RESTART: //start at beginning again
			cmdEEPtr = exEEPage==-1?EECMDPTR_INIT:0;
			break;
		case EECMD_END: //end script processing
			cmdEEPtr = -1;
			break;
		case EECMD_CONNECT: //reconnect USB
			USB_INTR_ENABLE |= (1 << USB_INTR_ENABLE_BIT);
			usbDeviceConnect();
			cmdEEPtr++;
			break;
		case EECMD_DISCONNECT: //disconnect USB
			if(usbInterruptIsReady()){
				USB_INTR_ENABLE &= ~(1 << USB_INTR_ENABLE_BIT);
				usbDeviceDisconnect();
				cmdEEPtr++;
				}
			break;
		default:
			break;
	}

	return;
}

int main()
{
	usbDeviceDisconnect();

	PORTB &= ~(1<<PORTB4);
	DDRB |= 1<<PORTB4;
	blinkit(3, 30);

	exEEcur=EXEECMD_WRITEBT; exEEstt=0; exEELen=0; exEEAddr=0; exEEPtr=shadowbuf;
	while(exEEcur!=EXEECMD_DONE && exEEcur!=EXEECMD_NOACK){
		exEEAction();
		_delay_loop_1(EXTEESPD);
		}
	if(exEEcur==EXEECMD_DONE) serEExist=1;
	exEEcur = EXEECMD_IDLE;
	exEEPage=-1;
	if(serEExist){
		blinkit(10, 5);

		cmdEEPtr=(eeprom_read_byte( (const void *) 0)<<8)|eeprom_read_byte( (const void *) 1);
		if(cmdEEPtr != -1){
			exEEPage=eeprom_read_byte( (const void *) 2);
			exEERestart=1;
			}
		else cmdEEPtr=0;
		}

	PORTB &= ~(1<<PORTB4);
	DDRB  &= ~(1<<PORTB4);
	scancode[0]=1;
	starting_up=1;
	exEEOffSec=-1;

	usbDeviceConnect();
	usbInit();

	timerInit();
	DDRB |= 1<<PORTB4;
	wdt_enable(WDTO_8S);

	sei();
	while(1){ // main program loop
		wdt_reset();
		usbPoll();
		check_eeprombt();
		while(exEEcur && exEEcur<EXEECMD_DONE && serEExist) exEEAction();
		updateEEBusy();

		if(!starting_up){

			if(echBufEnd && usbInterruptIsReady()){
				scancode[0]=1;
				scancode[1]=echmBuffer[0];
				scancode[2]=echcBuffer[0];
				usbSetInterrupt(scancode, sizeof(scancode));
				if(echBufEnd>1 && echcBuffer[0] != echcBuffer[1]) echPopFIFO();
				else if(!holdkey && echcBuffer[0]) echcBuffer[0]=0;
				else echPopFIFO();
				}
			if(!echBufEnd) cmdProcessPtr();

			}
		if(blinkTime){
			blinkit(1, 20);
			blinkTime--;
			}

		}
	
	return(0);
}
