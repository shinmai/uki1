/*
    ExtSerialEEPROM.c: slow serial two wire functions with non-standard pins
    Copyright (C) 2010  NOP Security

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define	SDA			PORTB0
#define	SCL			PORTB3

#define EXTEEID		0xA0

#define EXTEERD		1
#define EXTEESPD	30

#define	EXEECMD_IDLE	0x00
#define	EXEECMD_READBT	0x01
#define	EXEECMD_WRITEBT	0x02
#define	EXEECMD_ADDRNRD	0x03
#define	EXEECMD_DONE	0x7F
#define	EXEECMD_NOACK	0xFE
#define	EXEECMD_ERROR	0xFF

unsigned char	serEExist;		//External EEPROM exists?
unsigned char	exEEcur;
unsigned char	exEElast;
unsigned char	exEEstt;
unsigned int	exEEAddr;
         int	exEELen;
unsigned char	*exEEPtr;
unsigned char	tempwr;

void serialEEInit()
{
	USIDR  = 0;
	PORTB |= 1<<SCL;
	DDRB  |= 1<<SCL;
	PORTB &= ~(1<<SDA);
	_delay_loop_1(7);
	DDRB  &= ~(1<<SDA);
	USISR  = 0;
	return;
}

/*
void testSEE()
{
	serialEEInit();

	PORTB |= (1<<SDA) | (1<<SCL); // SCL & SDA high
	DDRB  |= 1<<SDA;
	_delay_loop_1(EXTEESPD*2);

	PORTB &= ~(1<<SDA); // SDA low <Start Condition>
//	USICR |= 1<<USICLK;
//	USISR |= 1<<USISIF;
	_delay_loop_1(EXTEESPD);

	PORTB ^= 1<<SCL; // SCL low <data change state>
	_delay_loop_1(EXTEESPD/2);
	USISR &= 0xF0;
	USIDR  = EXTEEID;
	if(USIDR&0x80) PORTB |= 1<<SDA;
	else PORTB &= ~(1<<SDA);

//	while((USISR&0xF) < 8){
	while(!(USISR&(1<<USIOIF))){
		_delay_loop_1(EXTEESPD);
		PORTB ^= 1<<SCL;
		USISR++;
		_delay_loop_1(EXTEESPD);
		PORTB ^= 1<<SCL;
		asm("NOP");
		USICR |= 1<<USICLK;
		if(USIDR&0x80) PORTB |= 1<<SDA;
		else PORTB &= ~(1<<SDA);
	}
	DDRB  &= ~(1<<SDA); // SCL low, disable SDA for ack detect
	_delay_loop_1(EXTEESPD);
	PORTB ^= 1<<SCL; // SCL high, check for ack
	_delay_loop_1(EXTEESPD/2);

	if((PINB&(1<<SDA))) serEExist=1;

	_delay_loop_1(EXTEESPD/2);
	PORTB ^= 1<<SCL; // scl low, reset SDA, ready for stop
	DDRB  |= 1<<SDA;
	DDRB  &= ~(1<<SCL);
	PORTB &= ~(1<<SDA);
	_delay_loop_1(EXTEESPD);
	PORTB |= 1<<SCL; // scl high <Stop Condition>
	do {_delay_loop_1(EXTEESPD/2);} while(!(PINB&(1<<SCL)));
	PORTB |= 1<<SDA;

	serialEEInit();

	return;
}*/

void readEEBytes() // read 2-wire, 2 cycles per clock
{
	switch(exEEstt){
		case 0:
			serialEEInit();
			PORTB |= (1<<SDA) | (1<<SCL); // SCL & SDA high
			DDRB  |= 1<<SDA;
			break;
		case 2: //+2 cycles
			PORTB &= ~(1<<SDA); // SDA low <Start Condition>
			break;
		case 4: //+2 cycles
			PORTB ^= 1<<SCL; // SCL low <data change state>
			break;
		case 5: //+1 cycles
			USISR &= 0xF0; // Set data register and first bit
			USIDR  = EXTEEID | EXTEERD;
			asm("NOP");
			if(USIDR&0x80) PORTB |= 1<<SDA;
			else PORTB &= ~(1<<SDA);
			break;
		case 7: //+2 cycles
			PORTB ^= 1<<SCL; //SCL high
			USISR++;
			break;
		case 9: //+2 cycles
			PORTB ^= 1<<SCL; //SCL low, set new bit
			USICR |= 1<<USICLK;
			asm("NOP");
			if(USIDR&0x80) PORTB |= 1<<SDA;
			else PORTB &= ~(1<<SDA);

			if(!(USISR&(1<<USIOIF))) exEEstt-=4;
			else DDRB  &= ~(1<<SDA); // data end, disable SDA for ack detect
			break;
		case 11: //+2 cycles
			PORTB ^= 1<<SCL; // SCL high, check for ack
			break;
		case 12: //+1 cycles
			if((PINB&(1<<SDA))){
				serialEEInit();
				exEEcur = EXEECMD_NOACK;
				return;
			}
			break;
		case 13: //+1 cycles
			PORTB ^= 1<<SCL; // SCL low, ready next input data
			USISR &= 0xF0; // Leave SDA as input and ready buffer
			break;
		case 15: //+2 cycles
			PORTB ^= 1<<SCL;  // SCL high, read data
			USISR++;
			USICR |= 1<<USICLK;
			break;
		case 17: //+2 cycles
			PORTB ^= 1<<SCL; // SCL low

			if(!(USISR&(1<<USIOIF))) exEEstt-=4;
			else{
				DDRB  |= 1<<SDA; // enable SDA for ack send
				*(exEEPtr++) = USIBR;
				if(--exEELen > 0) PORTB &= ~(1<<SDA); // ack
				else PORTB |= 1<<SDA; // nack
			}
			break;
		case 19: //+2 cycles
			PORTB ^= 1<<SCL; // SCL high, ack/nack
			break;
		case 21: //+2 cycles
			PORTB ^= 1<<SCL; // scl low, reset SDA, ready for next byte or stop
			DDRB  &= ~(1<<SDA);
			if(exEELen>0){
				USISR &= 0xF0; // Leave SDA as input and ready buffer
				exEEstt=13;
			}
			else PORTB &= ~(1<<SDA);
			break;
		case 23: //+2 cycles
			DDRB  &= ~(1<<SCL); // ready for stop
			PORTB |= 1<<SCL;	// scl high <Stop Condition>
			exEEstt++;
		case 24: //+1 cycles
			if(!(PINB&(1<<SCL))) exEEstt--;
			break;
		case 25: //+1 cycles
			DDRB  |= 1<<SDA;
			PORTB |= 1<<SDA;
			serialEEInit();
			exEEcur = EXEECMD_DONE;
			break;
		default:
			break;
	}
	exEEstt++;
	return;
}

void writeEEBytes(unsigned char realwrite) // write 2-wire, 2 cycles per clock
{ static unsigned char addrwr;
	switch(exEEstt){
		case 0:
			addrwr=0;
			serialEEInit();
			PORTB |= (1<<SDA) | (1<<SCL); // SCL & SDA high
			DDRB  |= 1<<SDA;
			break;
		case 2: //+2 cycles
			PORTB &= ~(1<<SDA); // SDA low <Start Condition>
			break;
		case 4: //+2 cycles
			PORTB ^= 1<<SCL; // SCL low <data change state>
			break;
		case 5: //+1 cycles
			USISR &= 0xF0; // Set data register and first bit
			USIDR  = EXTEEID;
			asm("NOP");
			if(USIDR&0x80) PORTB |= 1<<SDA;
			else PORTB &= ~(1<<SDA);
			break;
		case 7: //+2 cycles
			PORTB ^= 1<<SCL; //SCL high
			USISR++;
			break;
		case 9: //+2 cycles
			PORTB ^= 1<<SCL; //SCL low, set new bit
			USICR |= 1<<USICLK;
			asm("NOP");
			if(USIDR&0x80) PORTB |= 1<<SDA;
			else PORTB &= ~(1<<SDA);

			if(!(USISR&(1<<USIOIF))) exEEstt-=4;
			else DDRB  &= ~(1<<SDA); // data end, disable SDA for ack detect
			break;
		case 11: //+2 cycles
			PORTB ^= 1<<SCL; // SCL high, check for ack
			break;
		case 12: //+1 cycles
			if((PINB&(1<<SDA))){
				serialEEInit();
				exEEcur = EXEECMD_NOACK;
				return;
			}
			break;
		case 13: //+1 cycles
			PORTB ^= 1<<SCL; // SCL low, ready next input data
			DDRB  |= 1<<SDA;
			exEEstt= 5;
			USISR &= 0xF0; // Set data register and first bit
			switch(addrwr){
				case 0:
					USIDR  = exEEAddr>>8;
					addrwr++;
					break;
				case 1:
					USIDR  = exEEAddr&0xFF;
					addrwr++;
					break;
				default:
					if(realwrite && exEELen>0){
						USIDR = *(exEEPtr++);
						exEELen--;
						}
					else{
						USIDR = 0;
						exEEstt= 13;
						}
					break;
			}
			if(USIDR&0x80) PORTB |= 1<<SDA;
			else PORTB &= ~(1<<SDA);
			break;
		case 15: //+2 cycles
			DDRB  &= ~(1<<SCL); // ready for stop
			PORTB |= 1<<SCL;	// scl high <Stop Condition>
			exEEstt++;
		case 16: //+1 cycles
			if(!(PINB&(1<<SCL))) exEEstt--;
			break;
		case 17: //+1 cycles
			DDRB  |= 1<<SDA;
			PORTB |= 1<<SDA;
			serialEEInit();
			if(exEEcur == EXEECMD_ADDRNRD){
				exEEcur = EXEECMD_READBT;
				exEEstt = -1;
			}
			else exEEcur = EXEECMD_DONE;
			break;
		default:
			break;
	}
	exEEstt++;
	return;
}

void exEEAction()
{
	switch(exEEcur){
		case EXEECMD_READBT:
			exEElast=exEEcur;
			readEEBytes();
			break;
		case EXEECMD_WRITEBT:
			exEElast=exEEcur;
			writeEEBytes(TRUE);
			break;
		case EXEECMD_ADDRNRD:
			exEElast=exEEcur;
			writeEEBytes(FALSE);
			break;
		default:
			break;
	}
	return;
}

