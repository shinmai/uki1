/*
    Copyright (C) 2010  NOP Security

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define STARTUPDELAY	20 // wait ~5 seconds before processing for HID Driver to start

#define CONTROL_READ_EEBLOC			0x01
#define CONTROL_WRITE_EEBLOC		0x02
#define CONTROL_GETEECMDPTR			0x03
#define CONTROL_SETEECMDPTR			0x04
#define CONTROL_SET_EXEEPAGE		0x05
#define CONTROL_GET_EXEEPAGE		0x06
#define CONTROL_QECHOCHAR			0x20
#define CONTROL_STHOLDCHAR			0x21
#define CONTROL_ENABLE				0xFC
#define CONTROL_DISABLE				0xFD
#define CONTROL_BLINK				0xFE
#define CONTROL_CLEAR_STATUS		0xFF

#define STATUSR_IDLE				0x00
#define STATUSR_COMPLETE			0x01
#define STATUSR_RETRY				0xFC
#define STATUSR_EOF					0xFD
#define STATUSR_EEBUSY				0xFE
#define STATUSR_BUSY				0xFF

#define EECMDPTR_INIT				0x06
#define EECMDPTR_END				0x1FF  // Size of internal EEPROM - 1
#define EECMDSTART					0xE0

#define EECMD_PAGE					0xF0
#define EECMD_STRHEX16				0xF1
#define EECMD_STRHEXS				0xF2
#define EECMD_STRHEX				0xF3
#define EECMD_JUMP					0xF4
#define EECMD_GOTO					0xF5
#define EECMD_CONNECT				0xF6
#define EECMD_DISCONNECT			0xF7
#define EECMD_DELAYQ				0xF8
#define EECMD_STMODKEYS				0xF9
#define EECMD_DELAYSEC				0xFA
#define EECMD_DELAYMIN				0xFB
#define EECMD_DELAYHR				0xFC
#define EECMD_NOP					0xFD
#define EECMD_RESTART				0xFE
#define EECMD_END					0xFF

#define HEXEN_STR					0xFF
#define HEXEN_VAR					0xFE
#define HEXEN_RAW					0xFD
#define HEXEN_BASE					0xE0
