Enclosed are the source files for the NOP Security USB Key Injector 1.02 firmware.

The firmware image is "USBKeyInject.hex" which is uploaded to an ATTiny85-20 processor. The fuses must be set to (HIGHFUSE:0xDF) and (LOWFUSE:0xC1) which should set a couple options including the processor speed to 16Mhz using the PLL clock source. (16.5Mhz after it calibrates)

The rest of the files are source or generated files, or AVR Studio files. You can compile everything with AVR-gcc from the "default" directory using the "make" command or the batch file.