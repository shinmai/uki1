Included are example UKI script files for NOP Security's USB Key Injector, the JScript binary decoder for typed hex and the Masm assembly source for the small footprint shellcode launcher executable.

All UKI files are just raw code files and with some knowledge of commands, they can be edited using a regular hex editor. Or you can compile/parse them using one of the UKI utilities.

The launcher is ~(1k+shellcode) size footprint, using a swappable resource section. The SmExec source directory is compressed and encrypted with the password "smexec" so it won't trigger virus scanners. It should be linked with /align:16 or /align:32 to keep the file size small. See RadASM .rap file for compile and link commands. It works with most x86 raw shellcode from the Metasploit framework.

The "Notepad_JScript_filesave_shellfull.uki" file is an example of everything combined for rapid injection of variable shellcode on an XP system using a small amount of data.

