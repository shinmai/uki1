// JScript Hex Binary writer using ISO8859-1 codepage with no compression - Copyright � 2010 NOP Security
// Fill in string encoded hex below in place of \x00s, terminating each line with a \
// and return or put everything on one line
// Enter filename below (in place of exp.exe)
// Should function on XP and and later

var dt="\
\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\
";
var ts=WScript.CreateObject("ADODB.Stream");
ts.Open();
ts.Type=2;
ts.CharSet = 'ISO8859-1';
ts.WriteText(dt);
ts.SaveToFile("exp.exe",2); //Fill in filename as first argument here
ts.Close();
