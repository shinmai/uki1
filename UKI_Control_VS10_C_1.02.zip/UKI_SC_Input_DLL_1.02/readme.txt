This directory contains the files for the UKI Scancode Input DLL, which allows any program the ability to inject scancodes into the HID keystream using an easy library. See the example UKI DLL tester for how to implement it in a program. The files in the "Release" directory are the ones needed for use in another program. The necessary files are the include, which describes the exported functions and the scancode data struct, the library for linking and the DLL which contains the active code.

Keep in mind that while the code for the library is licensed under the GPL, the include, library and compiled DLL files themselves may be used in any program without license restriction.

Copyright 2010 NOP Security
See gpl.txt for licensing info on the code for the DLL
