/*
	UKI Scancode Input DLL : DLL for HID direct key injection over the UKI device
    Copyright (C) 2010  NOP Security

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdafx.h"
#include "UKI_SC_Input.h"
#include "scancode_map.h"

union spDiDDtlBuf {
	SP_DEVICE_INTERFACE_DETAIL_DATA SPDID;
	wchar_t pathbuf[MAX_PATH+sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA)];
};

HANDLE gDevHdl;

HANDLE HIDCheckDevForMatch(LPWSTR devpath, int vend, int prod, int vers)
{HANDLE devfile; HIDD_ATTRIBUTES HIDAttr;

	devfile = CreateFile(devpath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if(devfile == INVALID_HANDLE_VALUE){
		return(INVALID_HANDLE_VALUE);
	}

	HIDAttr.Size = sizeof(HIDAttr);
	if(!HidD_GetAttributes( devfile, &HIDAttr)){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	if(vend != -1 && HIDAttr.VendorID != vend){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	if(prod != -1 && HIDAttr.ProductID != prod){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	if(vers != -1 && HIDAttr.VersionNumber != vers){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	return(devfile);
}

int HIDScanListConnect(int vendid, int prodid)
{GUID guidbuf; HDEVINFO hdiSet; HANDLE hDev;
 SP_DEVICE_INTERFACE_DATA spDiD; spDiDDtlBuf spDiDDtl; 
 HIDD_ATTRIBUTES HIDAtt;
 int curdev;

	HidD_GetHidGuid(&guidbuf);
	hdiSet = SetupDiGetClassDevs(&guidbuf, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
	if(hdiSet == NULL){
		return(0);
	}
	spDiD.cbSize = sizeof(spDiD);
	spDiDDtl.SPDID.cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
	HIDAtt.Size = sizeof(HIDAtt);

	for(curdev=0; SetupDiEnumDeviceInterfaces(hdiSet, NULL, &guidbuf, curdev, &spDiD); curdev++){
		if(SetupDiGetDeviceInterfaceDetail(hdiSet, &spDiD, (SP_DEVICE_INTERFACE_DETAIL_DATA *) &spDiDDtl, sizeof(spDiDDtl), NULL, NULL)){
			hDev = HIDCheckDevForMatch(spDiDDtl.SPDID.DevicePath, vendid, prodid, -1);
			if(hDev != INVALID_HANDLE_VALUE){
				if(gDevHdl == INVALID_HANDLE_VALUE){
					gDevHdl = hDev;
				}
				else CloseHandle(hDev);
			}
		}
	}

	SetupDiDestroyDeviceInfoList(hdiSet);
	return(1);
}

int UKICommand(HANDLE hHID, unsigned char command, unsigned char argA, unsigned char argB, unsigned char argC)
{DWORD tmpx; unsigned char cmdin[3], cmdout[5];
	
	if(hHID == INVALID_HANDLE_VALUE) return(0);

	memset(cmdin, 0, 3); memset(cmdout, 0, 5); 
	cmdout[0] = 0x02;
	cmdout[1] = command;
	cmdout[2] = argA;
	cmdout[3] = argB;
	cmdout[4] = argC;
	cmdin[0] = 0x02;
	cmdin[1] = 0xFF;

	if(!WriteFile(hHID, cmdout, 5, &tmpx, NULL)){
		return(0);
	}

	tmpx = 0;
	while(cmdin[1] != STATUSR_COMPLETE && cmdin[1] != STATUSR_IDLE && cmdin[1] != STATUSR_EOF && tmpx++ < 200){
		HidD_GetInputReport(hHID, cmdin, 3);
	}

	if(cmdin[1] == STATUSR_EOF) return(-1);
	if(cmdin[1] != STATUSR_COMPLETE) return(0);
	return(1);
}

int UKIRCommand(HANDLE hHID, unsigned char command, unsigned char argA, unsigned char argB, unsigned char argC)
{DWORD tmpx; unsigned char cmdin[3], cmdout[5];
	
	if(hHID == INVALID_HANDLE_VALUE) return(0);

	memset(cmdin, 0, 3); memset(cmdout, 0, 5); 
	cmdout[0] = 0x02;
	cmdout[1] = command;
	cmdout[2] = argA;
	cmdout[3] = argB;
	cmdout[4] = argC;
	cmdin[0] = 0x02;
	cmdin[1] = 0xFF;
	cmdin[2] = 0x00;

	if(!WriteFile(hHID, cmdout, 5, &tmpx, NULL)){
		return(-1);
	}

	tmpx = 0;
	while(cmdin[1] != STATUSR_COMPLETE && cmdin[1] != STATUSR_IDLE && cmdin[1] != STATUSR_EOF && tmpx++ < 200){
		HidD_GetInputReport(hHID, cmdin, 3);
	}

	if(cmdin[1] == STATUSR_EOF || cmdin[1] != STATUSR_COMPLETE) return(-1);
	return(cmdin[2]);
}

int cvtToCtlCodes(unsigned char *ascii_buf, int ascii_sz, pUKIScancode_t ctlcode_buf, int ctlcode_sz, unsigned char modifiers)
{unsigned char lastbyte=-1; pUKIScancode_t curctlc=ctlcode_buf;
	
	for(int x=0; x<ascii_sz && (curctlc+1)<(ctlcode_buf+ctlcode_sz); x++){
		if(ascii_buf[x] == '~' && ascii_buf[++x] != '~' && ascii_buf[x] >= 0x30 && ascii_buf[x] <= 0x7A){
			if(lastbyte == AsciiToSpecialMap[ascii_buf[x]-0x30]){
				curctlc->code     = 0;
				curctlc->modifier = modifiers;
				curctlc++;
				lastbyte=0;
				if((curctlc+1)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
			}
			curctlc->code     = AsciiToSpecialMap[ascii_buf[x]-0x30];
			curctlc->modifier = modifiers;
			curctlc++;
			lastbyte = AsciiToSpecialMap[ascii_buf[x]-0x30];
		}
		else {
			if(lastbyte == AsciiToScancodeMap[(ascii_buf[x]<<1)+1]){
				curctlc->code     = 0;
				curctlc->modifier = modifiers;
				curctlc++;
				lastbyte=0;
				if((curctlc+1)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
			}
			curctlc->code     = AsciiToScancodeMap[(ascii_buf[x]<<1)+1];
			curctlc->modifier = AsciiToScancodeMap[(ascii_buf[x]<<1)] ^ modifiers;
			curctlc++;
			lastbyte = AsciiToScancodeMap[(ascii_buf[x]<<1)+1];
		}
	}
	if(lastbyte != 0){
		if((curctlc+1)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
		curctlc->code     = 0;
		curctlc->modifier = 0;
	}
	return(curctlc-ctlcode_buf);
}

UKI_SC_INPUT_API int fnUKI_SC_Init(int vendid, int prodid)
{int retval;

	if(gDevHdl != INVALID_HANDLE_VALUE) CloseHandle(gDevHdl);
	gDevHdl = INVALID_HANDLE_VALUE;

	retval = HIDScanListConnect(vendid, prodid);
	if(!retval || gDevHdl==INVALID_HANDLE_VALUE) return(0);

	if(!UKICommand(gDevHdl, CONTROL_DISABLE, 0, 0, 0)){
		CloseHandle(gDevHdl);
		gDevHdl = INVALID_HANDLE_VALUE;
		return(0);
	}

	if(!UKICommand(gDevHdl, CONTROL_STHOLDCHAR, 1, 0, 0)){ // Forces manual key clearing, but allows holding individual keys idly.
		CloseHandle(gDevHdl);
		gDevHdl = INVALID_HANDLE_VALUE;
		return(0);
	}

	return(1);
}

int fnUKI_SC_End()
{
	if(gDevHdl==INVALID_HANDLE_VALUE) return(0);

	UKICommand(gDevHdl, CONTROL_STHOLDCHAR, 0, 0, 0);

	if(gDevHdl != INVALID_HANDLE_VALUE) CloseHandle(gDevHdl);
	gDevHdl = INVALID_HANDLE_VALUE;

	return(1);
}

UKI_SC_INPUT_API int fnUKI_SC_InputAscii(unsigned char asciibyte)
{
	if(gDevHdl == INVALID_HANDLE_VALUE) return(0);
	return(UKICommand(gDevHdl, CONTROL_QECHOCHAR, AsciiToScancodeMap[(asciibyte<<1)+1], AsciiToScancodeMap[asciibyte<<1], NULL));
}

UKI_SC_INPUT_API int fnUKI_SC_InputSC(unsigned char code, unsigned char modifier)
{
	if(gDevHdl == INVALID_HANDLE_VALUE) return(0);
	return(UKICommand(gDevHdl, CONTROL_QECHOCHAR, code, modifier, NULL));
}

UKI_SC_INPUT_API int fnUKI_SC_sCvtAscii(char *ascii_buf, int ascii_sz, pUKIScancode_t ctlcode_buf, int ctlcode_sz, unsigned char modifiers)
{int retval;
	if(ascii_buf == NULL || ascii_sz<1 || ctlcode_buf==NULL || ctlcode_sz<1) return(-1);
	retval=cvtToCtlCodes((unsigned char *) ascii_buf, ascii_sz, ctlcode_buf, ctlcode_sz, modifiers);
	return(retval);
}

UKI_SC_INPUT_API int fnUKI_SC_isConnected()
{
	return(gDevHdl != INVALID_HANDLE_VALUE?1:0);
}
