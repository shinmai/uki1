/*
    Copyright (c) 2010 NOP Security
    You may use this section of code however you would like.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#ifdef UKI_SC_INPUT_EXPORTS
#define UKI_SC_INPUT_API __declspec(dllexport)
#else
#define UKI_SC_INPUT_API __declspec(dllimport)
#endif

//extern UKI_SC_INPUT_API int nUKI_SC_Input;

typedef struct UKIScancodeBuf {
	unsigned char code;
	unsigned char modifier;
} UKIScancode_t, *pUKIScancode_t;

UKI_SC_INPUT_API int fnUKI_SC_Init(int vendorid, int productid);
UKI_SC_INPUT_API int fnUKI_SC_InputAscii(unsigned char asciibyte);
UKI_SC_INPUT_API int fnUKI_SC_InputSC(unsigned char code, unsigned char modifier);
UKI_SC_INPUT_API int fnUKI_SC_sCvtAscii(char *ascii_buf, int ascii_sz, pUKIScancode_t, int ctlcode_sz, unsigned char modifiers);
UKI_SC_INPUT_API int fnUKI_SC_isConnected();
