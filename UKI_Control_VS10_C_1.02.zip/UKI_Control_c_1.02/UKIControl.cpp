/*
    UKIControl UKI Controller in VS C++
    Copyright (C) 2010  NOP Security

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdafx.h"
#include "UKIControl.h"

HINSTANCE hInst;
HWND hWin;
HANDLE gDevHdl;
TCHAR szTitle[100];
TCHAR szWindowClass[100];
unsigned int edtTxtLim;
char *inbuf=NULL;

union spDiDDtlBuf {
	SP_DEVICE_INTERFACE_DETAIL_DATA SPDID;
	wchar_t pathbuf[MAX_PATH+sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA)];
};

ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	MSG msg;
	HACCEL hAccelTable;

	LoadString(hInstance, IDS_APP_TITLE, szTitle, 100);
	LoadString(hInstance, IDC_UKIC, szWindowClass, 100);

	MyRegisterClass(hInstance);

	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_UKIC));

	while (GetMessage(&msg, NULL, 0, 0))
	{
		
		if(!TranslateAccelerator(hWin, hAccelTable, &msg) && !IsDialogMessage(hWin, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= DLGWINDOWEXTRA;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_UKIC));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_BTNFACE+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_HIDDLGMNU);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hWin=NULL;
   hInst = hInstance; // Store instance handle in our global variable

   CreateDialogParam(hInstance, MAKEINTRESOURCE(IDD_HIDDLG), NULL, (DLGPROC) WndProc, NULL);
   if (!hWin) return FALSE;

   ShowWindow(hWin, nCmdShow);
   UpdateWindow(hWin);

   return TRUE;
}

int addEditCtrlText(int editctrl, LPWSTR strptr)
{unsigned int tempdta;
	if(editctrl == NULL || strptr == NULL) return(0);

	SendDlgItemMessage(hWin, editctrl, EM_SETSEL, edtTxtLim, edtTxtLim);
	tempdta=SendDlgItemMessage(hWin, editctrl, EM_LINEINDEX, -1, 0) + 800;
	if(tempdta >= edtTxtLim){
		SendDlgItemMessage(hWin, editctrl, EM_SETSEL, 0, 1000);
		SendDlgItemMessage(hWin, editctrl, EM_REPLACESEL, 0, (LPARAM)L"");
		SendDlgItemMessage(hWin, editctrl, EM_SETSEL, edtTxtLim, edtTxtLim);
	}
	SendDlgItemMessage(hWin, editctrl, EM_REPLACESEL, 0, (LPARAM)strptr);
	SendDlgItemMessage(hWin, editctrl, EM_SETSEL, edtTxtLim, edtTxtLim);
	return(1);
}

int HIDDisplayCaps(HANDLE devfile)
{HIDP_CAPS HIDCaps; PHIDP_PREPARSED_DATA pPDTA; wchar_t txtbuf[150];

	if(!HidD_GetPreparsedData(devfile, &pPDTA)) return(0);
	if(!HidP_GetCaps(pPDTA, &HIDCaps)) return(0);

	wsprintf(txtbuf, L"UsagePage %04X\r\n", HIDCaps.UsagePage); addEditCtrlText(IDC_MAINTXT, txtbuf);
	wsprintf(txtbuf, L"Usage %04X\r\n", HIDCaps.Usage); addEditCtrlText(IDC_MAINTXT, txtbuf);
	wsprintf(txtbuf, L"Input Report Byte Length %04X\r\n", HIDCaps.InputReportByteLength); addEditCtrlText(IDC_MAINTXT, txtbuf);
	wsprintf(txtbuf, L"Output Report Byte Length %04X\r\n", HIDCaps.OutputReportByteLength); addEditCtrlText(IDC_MAINTXT, txtbuf);
	wsprintf(txtbuf, L"Feature Report Byte Length %04X\r\n", HIDCaps.FeatureReportByteLength); addEditCtrlText(IDC_MAINTXT, txtbuf);

	HidD_FreePreparsedData(pPDTA);
	return(1);
}

HANDLE HIDCheckDevForMatch(LPWSTR devpath, int vend, int prod, int vers, wchar_t *devser)
{HANDLE devfile; HIDD_ATTRIBUTES HIDAttr; wchar_t txtbuf[150];

	devfile = CreateFile(devpath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if(devfile == INVALID_HANDLE_VALUE){
		addEditCtrlText(IDC_MAINTXT, L"Dev file failed open.\r\n");
		return(INVALID_HANDLE_VALUE);
	}

	HIDAttr.Size = sizeof(HIDAttr);
	if(!HidD_GetAttributes( devfile, &HIDAttr)){
		addEditCtrlText(IDC_MAINTXT, L"Could not get attributes.\r\n");
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	wsprintf(txtbuf, L"Vend ID: %04X, Prod ID: %04X, Vers ID: %04X \r\n", HIDAttr.VendorID, HIDAttr.ProductID, HIDAttr.VersionNumber);
	addEditCtrlText(IDC_MAINTXT, txtbuf);
	memset(txtbuf, 0, sizeof(txtbuf));
	if(HidD_GetSerialNumberString(devfile, txtbuf, 150) && wcslen(txtbuf)!=0){
		addEditCtrlText(IDC_MAINTXT, txtbuf);
		addEditCtrlText(IDC_MAINTXT, L"\r\n");
	}
	HIDDisplayCaps(devfile);

	if(vend != -1 && HIDAttr.VendorID != vend){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	if(prod != -1 && HIDAttr.ProductID != prod){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	if(vers != -1 && HIDAttr.VersionNumber != vers){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	if(devser && wcsncmp(txtbuf, devser, wcslen(devser))){
		CloseHandle(devfile);
		return(INVALID_HANDLE_VALUE);
	}

	return(devfile);
}

int UKICommand(HANDLE hHID, unsigned char command, unsigned char argA, unsigned char argB, unsigned char argC)
{DWORD tmpx; unsigned char cmdin[3], cmdout[5];
	
	if(hHID == INVALID_HANDLE_VALUE) return(0);

	memset(cmdin, 0, 3); memset(cmdout, 0, 5); 
	cmdout[0] = 0x02;
	cmdout[1] = command;
	cmdout[2] = argA;
	cmdout[3] = argB;
	cmdout[4] = argC;
	cmdin[0] = 0x02;
	cmdin[1] = 0xFF;

	if(!WriteFile(hHID, cmdout, 5, &tmpx, NULL)){
		return(0);
	}

	tmpx = 0;
	while(cmdin[1] != STATUSR_COMPLETE && cmdin[1] != STATUSR_IDLE && cmdin[1] != STATUSR_EOF && tmpx++ < 200){
		HidD_GetInputReport(hHID, cmdin, 3);
	}

	if(cmdin[1] == STATUSR_EOF) return(-1);
	if(cmdin[1] != STATUSR_COMPLETE) return(0);
	return(1);
}

int UKIRCommand(HANDLE hHID, unsigned char command, unsigned char argA, unsigned char argB, unsigned char argC)
{DWORD tmpx; unsigned char cmdin[3], cmdout[5];
	
	if(hHID == INVALID_HANDLE_VALUE) return(0);

	memset(cmdin, 0, 3); memset(cmdout, 0, 5); 
	cmdout[0] = 0x02;
	cmdout[1] = command;
	cmdout[2] = argA;
	cmdout[3] = argB;
	cmdout[4] = argC;
	cmdin[0] = 0x02;
	cmdin[1] = 0xFF;
	cmdin[2] = 0x00;

	if(!WriteFile(hHID, cmdout, 5, &tmpx, NULL)){
		return(-1);
	}

	tmpx = 0;
	while(cmdin[1] != STATUSR_COMPLETE && cmdin[1] != STATUSR_IDLE && cmdin[1] != STATUSR_EOF && tmpx++ < 200){
		HidD_GetInputReport(hHID, cmdin, 3);
	}

	if(cmdin[1] == STATUSR_EOF || cmdin[1] != STATUSR_COMPLETE) return(-1);
	return(cmdin[2]);
}

int UKIReadEEBuf(HANDLE hHID, unsigned char *buffer, int length)
{DWORD tmpx; unsigned char cmdin[3], cmdout[5]; int retlen=length, binread=0; wchar_t textbuf[256];
	
	if(hHID == INVALID_HANDLE_VALUE) return(0);

	memset(cmdin, 0, 3); memset(cmdout, 0, 5); 
	cmdout[0] = 0x02;
	cmdout[1] = CONTROL_READ_EEBLOC;
	cmdin[0] = 0x02;
	retlen=(length>EEBuf_Size||length<1)?EEBuf_Size:length;

	for(int x=0; x<retlen; x++){
		cmdout[2]=x&0xFF;
		cmdout[3]=(x>>8)&0xFF;
		cmdin[1] = 0xFF;
		if(!WriteFile(hHID, cmdout, 5, &tmpx, NULL)){
			return(0);
		}

		if(x && (x&0x3FF) == 0){
			wsprintf(textbuf, L"Read %d bytes. Please wait...\r\n", x);
			addEditCtrlText(IDC_MAINTXT, textbuf);
		}

		tmpx = 0;
		while(cmdin[1] != STATUSR_COMPLETE && cmdin[1] != STATUSR_IDLE && tmpx++ < 200){
			if(!HidD_GetInputReport(hHID, cmdin, 3) || cmdin[1] == STATUSR_EOF) return(x);
		}
		if(cmdin[1] == STATUSR_COMPLETE){
			buffer[x]=cmdin[2];
			if(binread) binread--;
			if(!binread && (buffer[x]==EECMD_STRHEX || buffer[x]==EECMD_STRHEXS)) binread+=18;
			if(length<1 && x>=15 && !binread && (buffer[x]==EECMD_END || buffer[x]==EECMD_RESTART)) return(x+1);
		}
		else if(cmdin[1] == STATUSR_RETRY) x--;
		else if(cmdin[1] == STATUSR_IDLE) return(-2);
		else return(-1);
	}

	return(retlen);
}

int UKIWriteEEBuf(HANDLE hHID, unsigned char *buffer, int length)
{DWORD tmpx; unsigned char cmdin[3], cmdout[5]; int retlen=length; wchar_t textbuf[256];
	
	if(hHID == INVALID_HANDLE_VALUE) return(0);

	memset(cmdin, 0, 3); memset(cmdout, 0, 5); 
	cmdout[0] = 0x02;
	cmdout[1] = CONTROL_WRITE_EEBLOC;
	cmdin[0] = 0x02;
	retlen=(length>EEBuf_Size)?EEBuf_Size:length;

	for(int x=0; x<retlen; x++){
		cmdout[2]=x&0xFF;
		cmdout[3]=(x>>8)&0xFF;
		cmdout[4]=buffer[x];
		cmdin[1] = 0xFF;
		if(!WriteFile(hHID, cmdout, 5, &tmpx, NULL)){
			return(0);
		}

		if(x && (x&0x3FF) == 0){
			wsprintf(textbuf, L"Written %d bytes. Please wait...\r\n", x);
			addEditCtrlText(IDC_MAINTXT, textbuf);
		}

		tmpx = 0;
		while(cmdin[1] != STATUSR_COMPLETE && cmdin[1] != STATUSR_IDLE && tmpx++ < 200){
			if(!HidD_GetInputReport(hHID, cmdin, 3) || cmdin[1] == STATUSR_EOF) return(x);
		}
	}

	return(retlen);
}

int HIDScanListConnect()
{GUID guidbuf; HDEVINFO hdiSet; HANDLE hDev; int prodid, vendid;
 SP_DEVICE_INTERFACE_DATA spDiD; spDiDDtlBuf spDiDDtl; 
 HIDD_ATTRIBUTES HIDAtt;
 int curdev; wchar_t tbuf[MAX_PATH], devserial[MAX_PATH]; int errnum;

	GetDlgItemText(hWin, IDC_VENDID, tbuf, MAX_PATH);
	vendid=wcstol(tbuf, NULL, 16);
	GetDlgItemText(hWin, IDC_PRODID, tbuf, MAX_PATH);
	prodid=wcstol(tbuf, NULL, 16);
	GetDlgItemText(hWin, IDC_SERIAL, devserial, MAX_PATH);

	HidD_GetHidGuid(&guidbuf);
	hdiSet = SetupDiGetClassDevs(&guidbuf, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
	if(hdiSet == NULL){
		addEditCtrlText(IDC_MAINTXT, L"SetupDiGetClassDevs failed!\r\n");
		return(0);
	}
	spDiD.cbSize = sizeof(spDiD);
	spDiDDtl.SPDID.cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
	HIDAtt.Size = sizeof(HIDAtt);

	for(curdev=0; SetupDiEnumDeviceInterfaces(hdiSet, NULL, &guidbuf, curdev, &spDiD); curdev++){
		if(SetupDiGetDeviceInterfaceDetail(hdiSet, &spDiD, (SP_DEVICE_INTERFACE_DETAIL_DATA *) &spDiDDtl, sizeof(spDiDDtl), NULL, NULL)){
			wsprintf( tbuf, L"Found device: %s\r\n", spDiDDtl.SPDID.DevicePath );
			addEditCtrlText(IDC_MAINTXT, tbuf);
			hDev = HIDCheckDevForMatch(spDiDDtl.SPDID.DevicePath, vendid, prodid, -1, devserial);
			if(hDev != INVALID_HANDLE_VALUE){
				if(gDevHdl == INVALID_HANDLE_VALUE){
					addEditCtrlText(IDC_MAINTXT, L"Connected.\r\n");
					gDevHdl = hDev;
					curEEPage=UKIRCommand(gDevHdl, CONTROL_GET_EXEEPAGE, curEEPage&0xFF, (curEEPage>>8)&0xFF, 0);
					if(curEEPage==-1) addEditCtrlText(IDC_MAINTXT, L"Connected to internal EEPROM.\r\n");
					else addEditCtrlText(IDC_MAINTXT, L"Connected to external EEPROM.\r\n");
					if(curEEPage < 0 && EEBuf!=EEBuf_internal){
						EEBuf=EEBuf_internal;
						EEBuf_Len+=EECMDPTR_INIT;
					}
					if(curEEPage >= 0 && EEBuf!=EEBuf_external){
						EEBuf=EEBuf_external;
						EEBuf_Len-=EECMDPTR_INIT;
					}
				}
				else CloseHandle(hDev);
			}
		}
		else{
			errnum = GetLastError();
			if(errnum == ERROR_INVALID_PARAMETER) wsprintf( tbuf, L"Invalid Param\r\n" );
			else if(errnum == ERROR_INVALID_USER_BUFFER) wsprintf( tbuf, L"Invalid Buffer\r\n" );
			else wsprintf( tbuf, L"Fail: %08X\r\n", errnum );
			addEditCtrlText(IDC_MAINTXT, tbuf);
		}
	
	}

	SetupDiDestroyDeviceInfoList(hdiSet);
	return(1);
}

int cvtToCtlCodes(unsigned char *ascii_buf, int ascii_sz, unsigned char *ctlcode_buf, int ctlcode_sz, unsigned char modifiers)
{unsigned char lastbyte=-1, newmod=modifiers, lastmod=modifiers, *curctlc=ctlcode_buf;
	
	for(int x=0; x<ascii_sz && curctlc<(ctlcode_buf+ctlcode_sz); x++){
		if(ascii_buf[x] == '~' && ascii_buf[++x] != '~' && ascii_buf[x] >= 0x30 && ascii_buf[x] <= 0x7A){
			newmod = modifiers;
			if(newmod != lastmod){
				if((curctlc+2)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
				*curctlc++ = EECMD_STMODKEYS;
				*curctlc++ = newmod;
				lastmod = newmod;
			}
			if(lastbyte == AsciiToSpecialMap[ascii_buf[x]-0x30]){
				if((curctlc+1)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
				*curctlc++ = 0;
				lastbyte=0;
			}
			*curctlc++ = AsciiToSpecialMap[ascii_buf[x]-0x30];
			lastbyte = AsciiToSpecialMap[ascii_buf[x]-0x30];
		}
		else {
			newmod = AsciiToScancodeMap[(ascii_buf[x]<<1)] ^ modifiers;
			if(newmod != lastmod){
				if((curctlc+2)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
				*curctlc++ = EECMD_STMODKEYS;
				*curctlc++ = newmod;
				lastmod = newmod;
			}
			if(lastbyte == AsciiToScancodeMap[(ascii_buf[x]<<1)+1]){
				if((curctlc+1)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
				*curctlc++ = 0;
				lastbyte=0;
			}
			*curctlc++ = AsciiToScancodeMap[(ascii_buf[x]<<1)+1];
			lastbyte = AsciiToScancodeMap[(ascii_buf[x]<<1)+1];
		}
	}
	if(lastbyte != 0){
		if((curctlc)>=(ctlcode_buf+ctlcode_sz)) return(curctlc-ctlcode_buf);
		*curctlc++ = 0;
	}
	return(curctlc-ctlcode_buf);
}

int getAsciiFromSC(unsigned char scchr, unsigned char mods)
{int tx;

	for(tx=0; tx<sizeof(AsciiToScancodeMap); tx+=2)
		if(AsciiToScancodeMap[tx+1] == scchr &&
			(((AsciiToScancodeMap[tx]!=0)&&((mods&0x22)!=0)) ||
			 ((AsciiToScancodeMap[tx]==0)&&((mods&0x22)==0)) ))
			return(tx/2);
	for(tx=0; tx<sizeof(AsciiToSpecialMap); tx++)
		if(AsciiToSpecialMap[tx] == scchr)
			return((tx+0x30)*-1);
	return(0);
}

#define		printoln(chrline)	addEditCtrlText(IDC_MAINTXT, chrline)

int parseCtlCodes(unsigned char *scbuf, int scct)
{int retsz=0, tx, oi, tmpx; wchar_t databuf[512]; unsigned char lastch=0, mods=0;
	
	for(tx=0; tx<scct; tx++){

		switch(scbuf[tx]){
		case EECMD_END:
			printoln(L"<End script>\r\n");
			tx=scct;
			break;
		case EECMD_RESTART:
			printoln(L"<Restart from beginning>\r\n");
			tx=scct;
			break;
		case EECMD_NOP:
			printoln(L"<NOP>"); lastch=scbuf[tx];
			break;
		case EECMD_STRHEX16: lastch=scbuf[tx];
			tmpx=16;
			printoln(L"<");
			while(tmpx--){
				wsprintf(databuf, L"\\x%02X", scbuf[++tx]);
				printoln(databuf);
			}
			printoln(L">\r\n");
			break;
		case EECMD_STRHEXS: lastch=scbuf[tx];
			tmpx=scbuf[++tx];
			if(tmpx > HEXEN_BASE){
				switch(tmpx){
				case HEXEN_STR:
					printoln(L"<Set hex output to string hex>");
					break;
				case HEXEN_VAR:
					printoln(L"<Set hex output to variable hex>");
					break;
				case HEXEN_RAW:
					printoln(L"<Set hex output to raw hex>");
					break;
				default:
					break;
				}
				break;
			}
			if(tmpx > 16) tmpx=16;
			printoln(L"<");
			while(tmpx--){
				wsprintf(databuf, L"\\x%02X", scbuf[++tx]);
				printoln(databuf);
			}
			printoln(L">\r\n");
			break;
		case EECMD_STRHEX: lastch=scbuf[tx];
			wsprintf(databuf, L"<\\x%02X>", scbuf[++tx]);
			printoln(databuf);
			break;
		case EECMD_DELAYHR: lastch=scbuf[tx];
			wsprintf(databuf, L"<Delay ~%d hours.>", scbuf[++tx]);
			printoln(databuf);
			break;
		case EECMD_DELAYMIN: lastch=scbuf[tx];
			wsprintf(databuf, L"<Delay ~%d minutes.>", scbuf[++tx]);
			printoln(databuf);
			break;
		case EECMD_DELAYSEC: lastch=scbuf[tx];
			wsprintf(databuf, L"<Delay ~%d seconds.>", scbuf[++tx]);
			printoln(databuf);
			break;
		case EECMD_STMODKEYS:
			wsprintf(databuf, L"<Mod:%02X>", scbuf[++tx]);
			if(!lastch || lastch >= EECMDSTART || (scbuf[tx] && scbuf[tx] != 2)) printoln(databuf);
			mods=scbuf[tx]; lastch=scbuf[tx-1];
			break;
		case EECMD_DELAYQ: lastch=scbuf[tx];
			printoln(L"<Delay ~1/4 second.>");
			break;
		case EECMD_CONNECT: lastch=scbuf[tx];
			printoln(L"<Connect>");
			break;
		case EECMD_DISCONNECT: lastch=scbuf[tx];
			printoln(L"<Disconnect>");
			break;
		default:
			if(scbuf[tx]<EECMDSTART){
				if(!scbuf[tx] && lastch>=EECMDSTART) printoln(L"<key release>");
				if(scbuf[tx] != lastch){
					if(scbuf[tx]){
						oi=getAsciiFromSC(scbuf[tx], mods);
						if(oi=='\n') printoln(L"\r\n");
						else if(oi<0){
							oi*=-1;
							wsprintf(databuf, L"~%c", oi&0xFF);
							printoln(databuf);
						}
						else{
							databuf[0]=oi; databuf[1]=0;
							printoln(databuf);
						}
					}
				}
				lastch=scbuf[tx];
			}
			break;
		}

	}
	
	return(retsz);
}

DWORD EncodeFileOpen()
{wchar_t ofnbuffer[MAX_PATH]; OPENFILENAME ofndata; HANDLE hfile; DWORD readbytes; char bytebuf[16]; int origsize;

	memset(ofnbuffer, 0, sizeof ofnbuffer);
	memset(&ofndata, 0, sizeof ofndata);
	
	ofndata.lStructSize = sizeof ofndata;
	ofndata.hwndOwner = hWin;
	ofndata.hInstance = hInst;
	ofndata.lpstrFilter = L"All Files\0*.*\0";
	ofndata.nFilterIndex = 1;
	ofndata.lpstrFile = ofnbuffer;
	ofndata.nMaxFile = MAX_PATH;
	ofndata.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER;
	ofndata.lpstrTitle = L"Select file to open";
	if(!GetOpenFileName(&ofndata)){
		addEditCtrlText(IDC_MAINTXT, L"No file selected to open.\r\n");
		return(0);
	}

	hfile = CreateFile(ofnbuffer, FILE_GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(!hfile){
		addEditCtrlText(IDC_MAINTXT, L"Could not open file.\r\n");
		return(0);
	}

	origsize = EEBuf_Len;
	while(EEBuf_Len < EEBuf_Size){
		if(!ReadFile(hfile, bytebuf, 16, &readbytes, NULL) || (EEBuf_Len+readbytes+2) >= EEBuf_Size || !readbytes){
			addEditCtrlText(IDC_MAINTXT, L"Encode ended.\r\n");
			CloseHandle(hfile);
			return(EEBuf_Len-origsize);
		}
		if((readbytes&0xFF)==16){
			EEBuf[EEBuf_Len++]=EECMD_STRHEX16;
		}
		else{
			EEBuf[EEBuf_Len++]=EECMD_STRHEXS;
			EEBuf[EEBuf_Len++]=readbytes&0xFF;
		}
		memcpy(EEBuf+EEBuf_Len, bytebuf, readbytes);
		EEBuf_Len += readbytes;
	}

	CloseHandle(hfile);
	return(EEBuf_Len-origsize);
}

DWORD ImportFileOpen()
{wchar_t ofnbuffer[MAX_PATH]; OPENFILENAME ofndata; HANDLE hfile; DWORD readbytes;

	memset(ofnbuffer, 0, sizeof ofnbuffer);
	memset(&ofndata, 0, sizeof ofndata);
	
	ofndata.lStructSize = sizeof ofndata;
	ofndata.hwndOwner = hWin;
	ofndata.hInstance = hInst;
	ofndata.lpstrFilter = L"UKI Files\0*.uki\0All Files\0*.*\0";
	ofndata.nFilterIndex = 1;
	ofndata.lpstrFile = ofnbuffer;
	ofndata.nMaxFile = MAX_PATH;
	ofndata.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_EXPLORER;
	ofndata.lpstrTitle = L"Select file to open";
	ofndata.lpstrDefExt = L"uki";
	if(!GetOpenFileName(&ofndata)){
		addEditCtrlText(IDC_MAINTXT, L"No file selected to open.\r\n");
		return(0);
	}

	hfile = CreateFile(ofnbuffer, FILE_GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(!hfile){
		addEditCtrlText(IDC_MAINTXT, L"Could not open file.\r\n");
		return(0);
	}

	if(!ReadFile(hfile, EEBuf+EEBuf_Len, EEBuf_Size - EEBuf_Len, &readbytes, NULL)){
		addEditCtrlText(IDC_MAINTXT, L"Read failed.\r\n");
		CloseHandle(hfile);
		return(0);
	}

	EEBuf_Len += readbytes;
	CloseHandle(hfile);
	return(readbytes);
}

DWORD ExportFileSave()
{wchar_t ofnbuffer[MAX_PATH]; OPENFILENAME ofndata; HANDLE hfile; DWORD readbytes;

	memset(ofnbuffer, 0, sizeof ofnbuffer);
	memset(&ofndata, 0, sizeof ofndata);
	
	ofndata.lStructSize = sizeof ofndata;
	ofndata.hwndOwner = hWin;
	ofndata.hInstance = hInst;
	ofndata.lpstrFilter = L"UKI Files\0*.uki\0All Files\0*.*\0";
	ofndata.nFilterIndex = 1;
	ofndata.lpstrFile = ofnbuffer;
	ofndata.nMaxFile = MAX_PATH;
	ofndata.Flags = OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_EXPLORER;
	ofndata.lpstrTitle = L"Select file to write to";
	ofndata.lpstrDefExt = L"uki";
	if(!GetSaveFileName(&ofndata)){
		addEditCtrlText(IDC_MAINTXT, L"No file selected to save to.\r\n");
		return(0);
	}

	hfile = CreateFile(ofnbuffer, FILE_GENERIC_WRITE, NULL, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(!hfile){
		addEditCtrlText(IDC_MAINTXT, L"Could not open file for writing.\r\n");
		return(0);
	}

	if(!WriteFile(hfile, curEEPage==-1?EEBuf+EECMDPTR_INIT:EEBuf, curEEPage==-1?EEBuf_Len-EECMDPTR_INIT:EEBuf_Len, &readbytes, NULL)){
		addEditCtrlText(IDC_MAINTXT, L"Write failed.\r\n");
		CloseHandle(hfile);
		return(0);
	}

	CloseHandle(hfile);
	return(readbytes);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	unsigned char cmdin[3];
	int wmId, wmEvent; unsigned int tmpx, tmpy;
	wchar_t strbuf[300];
	char abuf[200], lchar;

	switch (message)
	{
	case WM_INITDIALOG:
		hWin = hWnd;
		SendDlgItemMessage(hWnd, IDC_INPUTTXT, EM_SETLIMITTEXT, EEBuf_Size-1, 0);
		SendDlgItemMessage(hWnd, IDC_MAINTXT, EM_SETLIMITTEXT, 0, 0);
		edtTxtLim=SendDlgItemMessage(hWnd, IDC_MAINTXT, EM_GETLIMITTEXT, 0, 0) - 0x100;
		gDevHdl = INVALID_HANDLE_VALUE;
		EEBuf = (unsigned char *) malloc(EEBuf_Size+EECMDPTR_INIT);
		if(EEBuf == NULL){
			MessageBox(hWnd, L"OOM!", L"Memory Error", MB_OK);
			DestroyWindow(hWnd);
			return(TRUE);
		}
		memset(EEBuf, 0, EEBuf_Size+EECMDPTR_INIT);
		memset(EEBuf, 0xFF, EECMDPTR_INIT);
		EEBuf_internal=EEBuf;
		EEBuf_external=EEBuf+EECMDPTR_INIT;
		inbuf = (char *) malloc(EEBuf_Size);
		if(inbuf == NULL){
			MessageBox(hWnd, L"OOM!", L"Memory Error", MB_OK);
			DestroyWindow(hWnd);
			return(TRUE);
		}
		memset(inbuf, 0, EEBuf_Size);
		EEBuf_Len=EECMDPTR_INIT;
		curModifiers=0;
		curEEPage=-1;
		SetDlgItemText(hWin, IDC_VENDID, L"16C0"); // set default VID:PID
		SetDlgItemText(hWin, IDC_PRODID, L"27DB");
		SetDlgItemText(hWin, IDC_SERIAL, L"NOPSecurity.net:UKI");
		return(TRUE);
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);

		if(!lParam){
			switch (wmId){
			case IDM_OPEN:
				tmpx = ImportFileOpen();
				if(tmpx){
					wsprintf(strbuf, L"Added %d bytes to buffer.\r\n", tmpx);
					addEditCtrlText(IDC_MAINTXT, strbuf);
				}
				break;
			case IDM_SAVE:
				tmpx = ExportFileSave();
				if(tmpx){
					wsprintf(strbuf, L"Saved bytes to file.\r\n", tmpx);
					addEditCtrlText(IDC_MAINTXT, strbuf);
				}
				break;
			case IDM_ENCODEFILE:
				tmpx = EncodeFileOpen();
				if(tmpx){
					wsprintf(strbuf, L"Encoded %d bytes to buffer as string hex variable.\r\n", tmpx);
					addEditCtrlText(IDC_MAINTXT, strbuf);
				}
				break;
			case IDM_ENCODESTR:
				addEditCtrlText(IDC_MAINTXT, L"Appending string hex encoding code.\r\n");
				if(EEBuf_Len+1 < EEBuf_Size){
					EEBuf[EEBuf_Len++]=EECMD_STRHEXS;
					EEBuf[EEBuf_Len++]=HEXEN_STR;
				}
				break;
			case IDM_ENCODEVAR:
				addEditCtrlText(IDC_MAINTXT, L"Appending variable hex encoding code.\r\n");
				if(EEBuf_Len+1 < EEBuf_Size){
					EEBuf[EEBuf_Len++]=EECMD_STRHEXS;
					EEBuf[EEBuf_Len++]=HEXEN_VAR;
				}
				break;
			case IDM_ENCODERAW:
				addEditCtrlText(IDC_MAINTXT, L"Appending raw hex encoding code.\r\n");
				if(EEBuf_Len+1 < EEBuf_Size){
					EEBuf[EEBuf_Len++]=EECMD_STRHEXS;
					EEBuf[EEBuf_Len++]=HEXEN_RAW;
				}
				break;
			case IDM_ABOUT:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
				break;
			case IDA_SELALL:
				tmpx=GetDlgCtrlID(GetFocus());
				SendDlgItemMessage(hWin, tmpx, EM_SETSEL, 0, -1);
				break;
			case IDM_EXIT:
				DestroyWindow(hWnd);
				break;
			default:
				return DefWindowProc(hWnd, message, wParam, lParam);
			}
		}
		else if(wmEvent == BN_CLICKED) switch(wmId){
		case IDC_SCANCONN:
			HIDScanListConnect();
			break;
		case IDC_DISCHID:
			if(gDevHdl != INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Disconnected.\r\n");
				CloseHandle(gDevHdl);
				gDevHdl=INVALID_HANDLE_VALUE;
			}
			else{
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
			}
			break;
		case IDC_READHIDSTAT:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			cmdin[0] = 0x02;
			if(!HidD_GetInputReport(gDevHdl, cmdin, 3)){
				addEditCtrlText(IDC_MAINTXT, L"Read Status Fail.\r\n");
				break;
			}
			wsprintf(strbuf, L"Status: %02X, %02X\r\n", cmdin[1], cmdin[2]);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			break;
		case IDC_TESTHID:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			addEditCtrlText(IDC_MAINTXT, L"Attempting 5 blinks.\r\n");
			UKICommand(gDevHdl, CONTROL_BLINK, 5, 0, 0);
			addEditCtrlText(IDC_MAINTXT, L"   Test sent.\r\n");
			break;
		case IDC_DISABLERUN:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			if(!UKICommand(gDevHdl, CONTROL_DISABLE, 0, 0, 0)){
				addEditCtrlText(IDC_MAINTXT, L"Control code fail.\r\n");
				break;
			}
			addEditCtrlText(IDC_MAINTXT, L"UKI Disabled.\r\n");
			break;
		case IDC_ENABLERUN:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			if(!UKICommand(gDevHdl, CONTROL_ENABLE, 0, 0, 0)){
				addEditCtrlText(IDC_MAINTXT, L"Control code fail.\r\n");
				break;
			}
			addEditCtrlText(IDC_MAINTXT, L"UKI Enabled.\r\n");
			break;
		case IDC_DLEEPROM:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf));
			tmpx=wcstol(strbuf, NULL, 0);
			addEditCtrlText(IDC_MAINTXT, L"Downloading EEPROM, please wait.\r\n");
			tmpx=UKIReadEEBuf(gDevHdl, EEBuf, tmpx);
			if(!tmpx || tmpx == -1){
				addEditCtrlText(IDC_MAINTXT, L"EEPROM download failed.\r\n");
				break;
			}
			if(tmpx == -2){
				addEditCtrlText(IDC_MAINTXT, L"EEPROM download command fail... device idle.\r\n");
				break;
			}
			EEBuf_Len=tmpx;
			wsprintf(strbuf, L"Bytes downloaded: %d\r\n", tmpx);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			break;
		case IDC_ULEEPROM:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			addEditCtrlText(IDC_MAINTXT, L"Uploading EEPROM, please wait.\r\n");
			if(!(tmpx=UKIWriteEEBuf(gDevHdl, EEBuf, EEBuf_Len))){
				addEditCtrlText(IDC_MAINTXT, L"EEPROM upload failed.\r\n");
				break;
			}
			EEBuf_Len=tmpx;
			wsprintf(strbuf, L"Bytes uploaded: %d\r\n", tmpx);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			break;
		case IDC_DUMPMEMHEX:
			wsprintf(strbuf, L"Hexdumping %d bytes from memory:\r\n", EEBuf_Len);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			for(unsigned int x=0; x<EEBuf_Len; x++){
				wsprintf(strbuf, L"%02X ", EEBuf[x]);
				addEditCtrlText(IDC_MAINTXT, strbuf);
				if((x&0xF) == 0xF) addEditCtrlText(IDC_MAINTXT, L"\r\n");
			}
			addEditCtrlText(IDC_MAINTXT, L"\r\n");
			break;
		case IDC_CLEARMEM:
			addEditCtrlText(IDC_MAINTXT, L"Deleting mem.\r\n");
			memset(EEBuf, 0, EEBuf_Size);
			if(curEEPage==-1){
				memset(EEBuf, 0xFF, EECMDPTR_INIT);
				EEBuf_Len=EECMDPTR_INIT;
			}
			else EEBuf_Len=0;
			curModifiers=0;
			break;
		case IDC_APPENDNUL:
			addEditCtrlText(IDC_MAINTXT, L"Appending null byte.\r\n");
			if(EEBuf_Len < EEBuf_Size) EEBuf[EEBuf_Len++]=0x00;
			break;
		case IDC_APPENDFIN:
			addEditCtrlText(IDC_MAINTXT, L"Appending Fin.\r\n");
			if(EEBuf_Len < EEBuf_Size) EEBuf[EEBuf_Len++]=EECMD_END;
			break;
		case IDC_APPENDRPT:
			addEditCtrlText(IDC_MAINTXT, L"Appending Repeat.\r\n");
			if(EEBuf_Len < EEBuf_Size) EEBuf[EEBuf_Len++]=EECMD_RESTART;
			break;
		case IDC_APPENDQD:
			addEditCtrlText(IDC_MAINTXT, L"Appending 1 quarter second delay.\r\n");
			if(EEBuf_Len < EEBuf_Size) EEBuf[EEBuf_Len++]=EECMD_DELAYQ;
			break;
		case IDC_APPENDCONN:
			addEditCtrlText(IDC_MAINTXT, L"Appending USB reconnect.\r\n");
			if(EEBuf_Len < EEBuf_Size) EEBuf[EEBuf_Len++]=EECMD_CONNECT;
			break;
		case IDC_APPENDDISCONN:
			addEditCtrlText(IDC_MAINTXT, L"Appending USB disconnect.\r\n");
			if(EEBuf_Len < EEBuf_Size) EEBuf[EEBuf_Len++]=EECMD_DISCONNECT;
			break;
		case IDC_SETEEPAGE:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			if(!GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf))){
				addEditCtrlText(IDC_MAINTXT, L"Enter EEPROM page to set to, or -1 for internal EEPROM.\r\n");
				break;
			}
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			curEEPage=wcstol(strbuf, NULL, 0);
			if(UKICommand(gDevHdl, CONTROL_SET_EXEEPAGE, curEEPage&0xFF, (curEEPage>>8)&0xFF, 0) == -1) addEditCtrlText(IDC_MAINTXT, L"ERROR: Possibly no external EEPROM.\r\n");
			curEEPage=UKIRCommand(gDevHdl, CONTROL_GET_EXEEPAGE, curEEPage&0xFF, (curEEPage>>8)&0xFF, 0);
			if(curEEPage >= 0) wsprintf(strbuf, L"Setting EEPROM memory page to %d.\r\nSet to -1 to address base EEPROM.\r\n", curEEPage);
			else wsprintf(strbuf, L"Memory set to base EEPROM.\r\n");
			addEditCtrlText(IDC_MAINTXT, strbuf);
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			if(curEEPage < 0 && EEBuf!=EEBuf_internal){
				EEBuf=EEBuf_internal;
				EEBuf_Len+=EECMDPTR_INIT;
			}
			if(curEEPage >= 0 && EEBuf!=EEBuf_external){
				EEBuf=EEBuf_external;
				EEBuf_Len-=EECMDPTR_INIT;
			}
			break;
		case IDC_STARTADDR:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			if(!GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf)) || curEEPage != -1){
				addEditCtrlText(IDC_MAINTXT, L"Please select base memory and enter the external EEPROM start address.\r\n");
				break;
			}
			tmpx=wcstol(strbuf, NULL, 0);
			EEBuf[0]=(tmpx>>8)&0xFF;
			EEBuf[1]=tmpx&0xFF;
			EEBuf[2]=0;
			if(!UKIWriteEEBuf(gDevHdl, EEBuf, 3)) addEditCtrlText(IDC_MAINTXT, L"ERROR: Possibly no external EEPROM.\r\n");
			else addEditCtrlText(IDC_MAINTXT, L"Set external EEPROM start address.\r\n");
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			break;
		case IDC_APPENDSECD:
			if(!GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf))) break;
			tmpx = _wtoi(strbuf)&0xFF;
			wsprintf(strbuf, L"Appending %d second delay.\r\n", tmpx);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			if(EEBuf_Len < EEBuf_Size-1){ EEBuf[EEBuf_Len++]=EECMD_DELAYSEC; EEBuf[EEBuf_Len++]=tmpx;}
			break;
		case IDC_APPENDMIND:
			if(!GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf))) break;
			tmpx = _wtoi(strbuf)&0xFF;
			wsprintf(strbuf, L"Appending %d minute delay.\r\n", tmpx);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			if(EEBuf_Len < EEBuf_Size-1){ EEBuf[EEBuf_Len++]=EECMD_DELAYMIN; EEBuf[EEBuf_Len++]=tmpx;}
			break;
		case IDC_APPENDHRD:
			if(!GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf))) break;
			tmpx = _wtoi(strbuf)&0xFF;
			wsprintf(strbuf, L"Appending %d hour delay.\r\n", tmpx);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			if(EEBuf_Len < EEBuf_Size-1){ EEBuf[EEBuf_Len++]=EECMD_DELAYHR; EEBuf[EEBuf_Len++]=tmpx;}
			break;
		case IDC_DELBYTES:
			if(!GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf))) break;
			tmpx = _wtoi(strbuf);
			wsprintf(strbuf, L"Deleting %d bytes.\r\n", tmpx);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			if(tmpx < EEBuf_Len) EEBuf_Len -= tmpx;
			else tmpx=0;
			break;
		case IDC_SETMODS:
			if(!GetDlgItemText(hWnd, IDC_INPUTTXT, strbuf, sizeof(strbuf))){ 
				addEditCtrlText(IDC_MAINTXT, ModsDescrip);
				break;
			}
			tmpx = wcstol(strbuf, NULL, 16)&0xFF;
			if(curModifiers != tmpx){
				wsprintf(strbuf, L"Setting modifiers to %02X.\r\n", tmpx);
				addEditCtrlText(IDC_MAINTXT, strbuf);
				if(EEBuf_Len < EEBuf_Size-1){ EEBuf[EEBuf_Len++]=EECMD_STMODKEYS; EEBuf[EEBuf_Len++]=tmpx;}
				curModifiers = tmpx;
				SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			}
			else {
				addEditCtrlText(IDC_MAINTXT, L"No change to modifiers.\r\n");
			}
			break;
		case IDC_CVTAPPEND:
			tmpx = GetDlgItemTextA(hWnd, IDC_INPUTTXT, inbuf, EEBuf_Size);
			if(!tmpx){
				addEditCtrlText(IDC_MAINTXT, SpecialMapDescrip);
				break;
			}
			inbuf[tmpx]=0;
			tmpx = cvtToCtlCodes((unsigned char *) inbuf, tmpx, EEBuf+EEBuf_Len, (EEBuf_Size-1)-EEBuf_Len, curModifiers);
			EEBuf_Len+=tmpx;
			wsprintf(strbuf, L"Appended %d bytes to output buffer for:\r\n", tmpx);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			SendDlgItemMessage(hWin, IDC_MAINTXT, EM_SETSEL, edtTxtLim, edtTxtLim);
			SendDlgItemMessageA(hWin, IDC_MAINTXT, EM_REPLACESEL, 0, (LPARAM)inbuf);
			wsprintf(strbuf, L"Buffer total bytes: %d.\r\n", EEBuf_Len);
			addEditCtrlText(IDC_MAINTXT, strbuf);
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			break;
		case IDC_ECHOCHAR:
			if(gDevHdl == INVALID_HANDLE_VALUE) HIDScanListConnect();
			if(gDevHdl == INVALID_HANDLE_VALUE){
				addEditCtrlText(IDC_MAINTXT, L"Not connected.\r\n");
				break;
			}
			if(!(tmpx = GetDlgItemTextA(hWnd, IDC_INPUTTXT, abuf, sizeof(abuf)-1))){
				addEditCtrlText(IDC_MAINTXT, SpecialMapDescrip);
				break;
			}
			abuf[tmpx]=0;
			SetDlgItemText(hWin, IDC_INPUTTXT, L"");
			SetFocus(GetDlgItem(hWin, IDC_INPUTTXT));
			lchar=0;
			for(tmpy=0; tmpy<tmpx; tmpy++){
				if(lchar == abuf[tmpy]) UKICommand(gDevHdl, CONTROL_QECHOCHAR, 0, 0, NULL);
				if(abuf[tmpy] != '~') UKICommand(gDevHdl, CONTROL_QECHOCHAR, AsciiToScancodeMap[(abuf[tmpy]<<1)+1], AsciiToScancodeMap[abuf[tmpy]<<1], NULL);
				else UKICommand(gDevHdl, CONTROL_QECHOCHAR, AsciiToSpecialMap[abuf[++tmpy]-0x30], 0, NULL);
				lchar=abuf[tmpy];
			}
			UKICommand(gDevHdl, CONTROL_QECHOCHAR, 0, 0, NULL);
			UKICommand(gDevHdl, CONTROL_QECHOCHAR, 0, 0, NULL);
			addEditCtrlText(IDC_MAINTXT, L"Text echoed.\r\n");
			break;
		case IDC_PARSEMEM:
			parseCtlCodes(curEEPage==-1?EEBuf+EECMDPTR_INIT:EEBuf, curEEPage==-1?EEBuf_Len-EECMDPTR_INIT:EEBuf_Len);
			addEditCtrlText(IDC_MAINTXT, L"Parse complete.\r\n");
			break;
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		if(gDevHdl != INVALID_HANDLE_VALUE){
			CloseHandle(gDevHdl);
			gDevHdl = INVALID_HANDLE_VALUE;
		}
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
