#pragma once

#define PROGMEM 

extern "C"{
#include <setupapi.h>
#include <hidsdi.h>
}
#include "resource.h"
#include "USBKeyInject.h"
#include "scancode_map.h"
#include "Dialogs\resource.h"

#define	EEBuf_Size	0x10000

unsigned char *EEBuf;
unsigned char *EEBuf_internal;
unsigned char *EEBuf_external;
unsigned int  EEBuf_Len;
unsigned char curModifiers;
int			  curEEPage;