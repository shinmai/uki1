UKI Control v1.02 - VS C version

This directory contains the source and executable for the Windows Visual Studio 10 version of the UKI Controller.

You should be able to run the executable under the "Release" directory, or open the .sln file in VS and recompile the project. You will need the HID library and include files from the Windows DDK in order to recompile it.

Unfortunately, Visual Studio 10 has apparently dropped support of Win 2k executables, but I would guess you can still compile it under an earlier version of Visual Studio in order to get around that. Or use the MASM version of the UKI Controller.

Copyright 2010 NOP Security
See gpl.txt for license info.
