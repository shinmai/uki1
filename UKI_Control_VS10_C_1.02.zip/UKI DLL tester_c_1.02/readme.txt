This directory contains the example source for how to implement the UKI Scancode DLL in an application to inject keystrokes into the HID keystream.

Copyright 2010 NOP Security
There are no licensing restrictions on any of these files. Use them as you wish.