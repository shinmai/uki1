This directory contains the schematics and board files for the UKI. PDF files are also supplied.

All originals are Copyright 2010 NOP Security and licensed as open-source via the GPL. See license.txt for details.